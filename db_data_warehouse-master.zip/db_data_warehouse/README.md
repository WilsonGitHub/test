# db_data_warehouse

电商数仓项目相关代码