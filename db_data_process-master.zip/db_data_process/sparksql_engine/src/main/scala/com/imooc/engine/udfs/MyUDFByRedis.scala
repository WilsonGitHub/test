package com.imooc.engine.udfs

import org.apache.spark.sql.api.java.UDF1
import redis.clients.jedis.Jedis

/**
 * 基于Redis的自定义函数
 *
 * 注意：在这里每次创建新连接
 * Created by xuwei
 */
class MyUDFByRedis extends UDF1[String,String]{

  override def call(t1: String): String = {
    //创建jedis连接
    val jedis = new Jedis("bigdata04", 6379)
    val value = jedis.get("k1")
    //关闭连接
    jedis.close()
    //把redis中获取到的k1的值，拼接到t1后面
    t1+"_"+value
  }
}
