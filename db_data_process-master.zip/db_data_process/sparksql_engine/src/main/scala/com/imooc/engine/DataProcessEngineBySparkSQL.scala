package com.imooc.engine

import java.util.Properties

import com.alibaba.fastjson.{JSON, JSONObject}
import com.imooc.engine.udfs.MyUDFTest
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
import org.apache.kafka.common.serialization.{StringDeserializer, StringSerializer}
import org.apache.spark.SparkConf
import org.apache.spark.sql.api.java.{UDF1, UDF2, UDF3}
import org.apache.spark.sql.types.{BooleanType, DoubleType, FloatType, IntegerType, LongType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, KafkaUtils, LocationStrategies}
import org.apache.spark.streaming.{Seconds, StreamingContext}

import scala.collection.mutable.ArrayBuffer

/**
 * 基于SparkSQL+SparkStreaming的通用实时计算引擎
 *
 * 1:抽取方法，优化代码，支持常见基本数据类型
 *
 * Created by xuwei
 */
object DataProcessEngineBySparkSQL {
  def main(args: Array[String]): Unit = {
    var masterUrl = "local[2]"
    var appSecond = 5
    var appName = "DataProcessEngineBySparkSQL"
    var inKafkaServers = "bigdata01:9092,bigdata02:9092,bigdata03:9092"//输入kafka地址
    var outKafkaServers = "bigdata01:9092,bigdata02:9092,bigdata03:9092"//输出kafka地址
    var inTopic = "stu"//输入kafka的topic名称
    var outTopic = "stu_clean"//输出kafka的topic名称
    var groupId = "g1"//kafka消费者的groupId
    var inSchemalInfo = "{\"name\":\"string\",\"age\":\"int\"}"//输入数据Schema信息
    var outSchemaInfo = "{\"newname\":\"string\",\"age\":\"int\"}"//输出数据Schema信息
    var funcInfo = "[{\"name\":\"m1\",\"mainClass\":\"com.imooc.engine.udfs.MyUDF1\",\"param\":\"(string)\",\"returnType\":\"string\"}]"//json数组，需要使用的udf
    //注意：针对sparksql 查询的字段顺序和目标表的字段顺序可以不一致
    var sql = "select m1(name) as newname,age from source"//用户输入的sql
    if(args.length==12){
      masterUrl = args(0)
      appSecond = args(1).toInt
      appName = args(2)
      inKafkaServers = args(3)
      outKafkaServers = args(4)
      inTopic = args(5)
      outTopic = args(6)
      groupId = args(7)
      inSchemalInfo = args(8)
      outSchemaInfo = args(9)
      funcInfo = args(10)
      sql = args(11)
    }

    //获取spark相关配置
    val conf = new SparkConf().setMaster(masterUrl).setAppName(appName)
    val ssc = new StreamingContext(conf, Seconds(appSecond))
    val sparkSession = SparkSession.builder().config(conf).getOrCreate()

    //配置输入数据源kafka参数
    val inKafkaParams = getInKafkaServerConfig(inKafkaServers,groupId)

    //指定输入Topic名称
    val topics = Array(inTopic)

    //获取输入kafka数据流
    val stream = KafkaUtils.createDirectStream[String, String](
      ssc,
      LocationStrategies.PreferConsistent,
      ConsumerStrategies.Subscribe[String, String](topics, inKafkaParams)
    )

    stream.map(_.value()).foreachRDD(rdd=>{
      //1:获取输入数据的schema信息，组装st
      val st = generateST(inSchemalInfo)

      //2:解析输入的数据，组装Row
      val rowRDD = rdd.map(line=>{
        generateRow(line,inSchemalInfo)
      })
      //3:建表
      val rowDF = sparkSession.createDataFrame(rowRDD, st)
      //表名统一设置为source
      rowDF.createOrReplaceTempView("source")
      //4:注册自定义函数
      //注册公共自定义函数
      sparkSession.udf.register("myUDF",new MyUDFTest,StringType)
      //注册个性化自定义函数
      registerUDF(funcInfo,sparkSession)

      //5:接收用户传递过来的SQL，执行查询操作
      val resDF = sparkSession.sql(sql)

      //6:解析SQL的执行结果
      resDF.rdd.foreachPartition(pr=>{
        val properties = getOutKafkaServerConfig(outKafkaServers)
        val producer = new KafkaProducer[String, String](properties)
        pr.foreach(row=>{
          //把计算之后的结果输出到kafka中，根据输出数据schema信息获取字段内容
          val resJson = generateRes(outSchemaInfo,row)
          producer.send(new ProducerRecord(outTopic,resJson.toString))
        })
        producer.close()
      })
    })

    ssc.start()
    ssc.awaitTermination()
  }

  /**
   * 组装Kafka的配置参数
   * @param inKafkaServers
   * @param groupId
   * @return
   */
  def getInKafkaServerConfig(inKafkaServers: String,groupId: String): Map[String,Object] ={
    Map[String,Object](
      "bootstrap.servers" ->inKafkaServers,
      "key.deserializer" ->classOf[StringDeserializer],
      "value.deserializer" ->classOf[StringDeserializer],
      "group.id" -> groupId,
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (true: java.lang.Boolean)
    )
  }

  /**
   * 组装StructType
   * @param inSchemalInfo
   * @return
   */
  def generateST(inSchemalInfo: String): StructType ={
    val inSchemaInfoJson = JSON.parseObject(inSchemalInfo)
    val it = inSchemaInfoJson.entrySet().iterator()
    val sfBuff = new ArrayBuffer[StructField]()
    while(it.hasNext){
      val entry = it.next()
      val fieldName = entry.getKey
      val fieldType = entry.getValue.toString
      fieldType match {
        case "string" => sfBuff.append(StructField(fieldName,StringType,nullable = false))
        case "int" => sfBuff.append(StructField(fieldName,IntegerType,nullable = false))
        case "long" => sfBuff.append(StructField(fieldName,LongType,nullable = false))
        case "float" => sfBuff.append(StructField(fieldName,FloatType,nullable = false))
        case "double" => sfBuff.append(StructField(fieldName,DoubleType,nullable = false))
        case "boolean" => sfBuff.append(StructField(fieldName,BooleanType,nullable = false))
        case _ => sfBuff.append(StructField(fieldName,StringType,nullable = false))
      }
    }
    StructType(sfBuff.toArray)
  }

  /**
   * 组装Row
   * @param line
   * @param inSchemalInfo
   */
  def generateRow(line: String,inSchemalInfo: String): Row ={
    //解析输入的数据(json格式)
    val lineJson = JSON.parseObject(line)
    //这里需要根据输入数据schema信息获取字段，根据字段获取值，进行拼接
    val inSchemaInfoJson = JSON.parseObject(inSchemalInfo)
    val it2 = inSchemaInfoJson.entrySet().iterator()
    val vBuff = new ArrayBuffer[Any]()
    while(it2.hasNext){
      val entry = it2.next()
      val fieldName = entry.getKey
      val fieldType = entry.getValue.toString
      fieldType match{
        case "string" => vBuff.append(lineJson.getString(fieldName))
        case "int" => vBuff.append(lineJson.getIntValue(fieldName))
        case "long" => vBuff.append(lineJson.getLongValue(fieldName))
        case "float" => vBuff.append(lineJson.getFloatValue(fieldName))
        case "double" => vBuff.append(lineJson.getDoubleValue(fieldName))
        case "boolean" => vBuff.append(lineJson.getBooleanValue(fieldName))
        case _ => vBuff.append(lineJson.getString(fieldName))
      }
    }
    Row.fromSeq(vBuff)
  }

  /**
   * 注册个性化自定义UDF
   * @param funcInfo
   * @param sparkSession
   */
  def registerUDF(funcInfo: String,sparkSession: SparkSession): Unit ={
    if(!"".equals(funcInfo.trim)){
      val funcInfoArr = JSON.parseArray(funcInfo)
      for(i <- 0 until funcInfoArr.size()){
        val jsonObj = funcInfoArr.getJSONObject(i)
        val name = jsonObj.getString("name")
        val mainClass = jsonObj.getString("mainClass")
        val returnType = jsonObj.getString("returnType")
        //(string,string)
        val tmpParam = jsonObj.getString("param").replace("(","").replace(")","")
        val paramArr = tmpParam.split(",")
        val rType = if(returnType=="string"){
          StringType
        }else{
          StringType
        }
        paramArr.size match{
          case 1 => sparkSession.udf.register(name,Class.forName(mainClass).newInstance().asInstanceOf[UDF1[String,String]],rType)
          case 2 => sparkSession.udf.register(name,Class.forName(mainClass).newInstance().asInstanceOf[UDF2[String,String,String]],rType)
          case 3 => sparkSession.udf.register(name,Class.forName(mainClass).newInstance().asInstanceOf[UDF3[String,String,String,String]],rType)
        }
      }
    }
  }

  /**
   * 组装kafka的配置参数
   * @param outKafkaServers
   * @return
   */
  def getOutKafkaServerConfig(outKafkaServers: String): Properties ={
    val properties = new Properties()
    properties.put("bootstrap.servers",outKafkaServers)
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,classOf[StringSerializer].getName)
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,classOf[StringSerializer].getName)
    properties
  }

  /**
   * 组装结果数据
   * @param outSchemaInfo
   * @param row
   * @return
   */
  def generateRes(outSchemaInfo: String,row: Row): JSONObject ={
    val resJson = new JSONObject()
    val outSchemaInfoJson = JSON.parseObject(outSchemaInfo)
    val it3 = outSchemaInfoJson.entrySet().iterator()
    while(it3.hasNext){
      val entry = it3.next()
      val fieldName = entry.getKey
      val valueType = entry.getValue.toString
      valueType match {
        case "string" => resJson.put(fieldName,row.getAs[String](fieldName))
        case "int" => resJson.put(fieldName,row.getAs[Int](fieldName))
        case "long" => resJson.put(fieldName,row.getAs[Long](fieldName))
        case "float" => resJson.put(fieldName,row.getAs[Float](fieldName))
        case "double" => resJson.put(fieldName,row.getAs[Double](fieldName))
        case "boolean" => resJson.put(fieldName,row.getAs[Boolean](fieldName))
        case _ => resJson.put(fieldName,row.getAs[String](fieldName))
      }
    }
    resJson
  }

}
