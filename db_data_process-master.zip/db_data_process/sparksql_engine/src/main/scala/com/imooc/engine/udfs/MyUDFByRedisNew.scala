package com.imooc.engine.udfs

import com.imooc.engine.utils.RedisUtil
import org.apache.spark.sql.api.java.UDF1

/**
 * 基于Redis的自定义函数
 *
 * 注意：
 * 连接池相关代码需要写到call函数内部，否则程序会报错，提示无法序列化
 * 在RedisUtil中定义的有一个静态连接池工具类
 * 在这里直接使用此工具类，可以保证在一个Executor内部共用一个连接池中的连接
 * 所以，这里的连接池中不需要初始化过多连接
 * 如果一个executor可用cpu核数为8，那么一个executor中最多同是并行执行8个task
 * 这个时候这里的连接池中连接数量最好设置为超过8个
 * Created by xuwei
 */
class MyUDFByRedisNew extends UDF1[String,String]{
  override def call(t1: String): String = {
    //创建静态连接池
    //注意：为了方便验证连接数量，暂时设置为1，实际工作中需要根据executor中可用的cpu核数来确定
    RedisUtil.makePool("bigdata04",6379,1)
    val pool = RedisUtil.getPool
    val jedis = pool.getResource
    val value = jedis.get("k1")
    //把连接返回连接池
    jedis.close()
    //把redis中获取到的k1的值，拼接到t1后面
    t1+"_"+value+"_new"
  }
}
