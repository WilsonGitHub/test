package com.imooc.engine.udfs

import org.apache.spark.sql.api.java.UDF1

import scala.util.Random

/**
 * 支持自定义函数返回多列字段
 * Created by xuwei
 */
class MyUDFMoreField extends UDF1[String,String]{
  override def call(t1: String): String = {
    //根据某一个字段，调用算法接口，最终需要返回多个字段
    //省略了调用算法接口的过程，直接返回一个JSON字符串
    val i = Random.nextInt(1000)
    "{\"newname\":\""+t1+i+"\",\"city\":\"bj"+i+"\"}"
  }
}
