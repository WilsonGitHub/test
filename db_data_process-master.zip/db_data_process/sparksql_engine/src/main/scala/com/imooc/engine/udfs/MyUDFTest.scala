package com.imooc.engine.udfs

import org.apache.spark.sql.api.java.UDF1

/**
 * 自定义函数(UDF)
 *    前面的泛型参数(不包含最后一个)表示接收数据的类型
 *    最后一个泛型参数表示返回值的类型
 *    如果自定义函数需要接收1个参数，则需要继承UDF1
 *    如果自定义函数需要接收2个参数，则需要继承UDF2
 *    以此类推...
 *
 * Created by xuwei
 */
class MyUDFTest extends UDF1[String,String]{
  override def call(t1: String): String = {
    t1+"_test"
  }
}
