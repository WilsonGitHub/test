package com.imooc.engine.udfs

import org.apache.flink.table.functions.ScalarFunction

/**
  * 自定义UDF
  * Created by xuwei
  */
class FlinkMyUDF1 extends ScalarFunction{
  def eval(str: String): String = {
    str+"_finknew"
  }
}
