package com.imooc.engine

import com.imooc.engine.udfs.FlinkMyUDFTest
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment

/**
 * 基于FlinkSQL的通用实时计算引擎
 * Created by xuwei
 */
object DataProcessEngineByFlinkSQLTest {
  def main(args: Array[String]): Unit = {
    //获取StreamTableEnviroment
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val ssSettings = EnvironmentSettings.newInstance().useBlinkPlanner().inStreamingMode().build()
    val ssTableEnv = StreamTableEnvironment.create(env, ssSettings)

    //组装source表建表语句
    val inTableSql ="""
                    |create table source(
                    |name string,
                    |age int
                    |) with(
                    |'connector' = 'kafka',
                    |'topic' = 'stu',
                    |'properties.bootstrap.servers' = 'bigdata01:9092,bigdata02:9092,bigdata03:9092',
                    |'properties.group.id' = 'g2',
                    |'format' = 'json',
                    |'scan.startup.mode' = 'latest-offset',
                    |'json.fail-on-missing-field' = 'false',
                    |'json.ignore-parse-errors' = 'true'
                    |)
                    |""".stripMargin
    ssTableEnv.executeSql(inTableSql)

    //组装sink表建表语句
    val outTableSql ="""
                  |create table sink(
                  |newname string,
                  |age int
                  |) with(
                  |'connector' = 'kafka',
                  |'topic' = 'stu_clean',
                  |'properties.bootstrap.servers' = 'bigdata01:9092,bigdata02:9092,bigdata03:9092',
                  |'format' = 'json',
                  |'sink.partitioner' = 'round-robin'
                  |)
                  |""".stripMargin
    ssTableEnv.executeSql(outTableSql)

    //注册自定义函数
    ssTableEnv.createTemporaryFunction("myUDF",new FlinkMyUDFTest)

    //执行sql查询
    val res = ssTableEnv.sqlQuery("select myUDF(name) as newname,age from source")
    //保存结果
    res.executeInsert("sink")

  }

}
