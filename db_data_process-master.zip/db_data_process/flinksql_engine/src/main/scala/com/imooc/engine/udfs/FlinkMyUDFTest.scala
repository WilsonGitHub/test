package com.imooc.engine.udfs

import org.apache.flink.table.functions.ScalarFunction

/**
 * 自定义函数
 * Created by xuwei
 */
class FlinkMyUDFTest extends ScalarFunction{
   def eval(str: String): String={
     str+"_flinktest"
   }
}
