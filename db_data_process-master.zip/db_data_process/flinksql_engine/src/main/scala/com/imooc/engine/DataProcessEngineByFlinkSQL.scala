package com.imooc.engine

import com.alibaba.fastjson.JSON
import com.alibaba.fastjson.parser.Feature
import com.imooc.engine.udfs.FlinkMyUDFTest
import org.apache.flink.streaming.api.scala.StreamExecutionEnvironment
import org.apache.flink.table.api.EnvironmentSettings
import org.apache.flink.table.api.bridge.scala.StreamTableEnvironment
import org.apache.flink.table.functions.ScalarFunction

/**
 * 基于FlinkSQL的通用实时计算引擎
 *
 * Created by xuwei
 */
object DataProcessEngineByFlinkSQL {
  def main(args: Array[String]): Unit = {
    var inKafkaServers = "bigdata01:9092,bigdata02:9092,bigdata03:9092" //输入kafka地址
    var outKafkaServers = "bigdata01:9092,bigdata02:9092,bigdata03:9092" //输出kafka地址
    var inTopic = "stu"  //输入kafka中的topic名称
    var outTopic = "stu_clean" //输出kafka中的topic名称
    var groupId = "g2" //kafka消费者的groupId
    //演示一下array数据类型 array<string>  array<int>
    var inSchemaInfo = "{'name':'string','age':'int','favors':'array<string>'}" //输入数据Schema信息
    var outSchemaInfo = "{'newname':'string','age':'int','favors':'array<string>'}" //输出数据Schema信息
    var funcInfo = "[{'name':'m1','mainClass':'com.imooc.engine.udfs.FlinkMyUDF1','param':'(String)','returnType':'string'}]" //json数组,需要使用的udf
    //注意：这里sql中的查询字段个数以及顺序都要和输出表中的字段个数和顺序保持一致
    //暂时在JSON中添加Feature.OrderedField保证解析出来的字段顺序不变
    //其实最好的是实现一个sql解析器，解析sql查询语句中的字段，按照此顺序生成输出表的字段
    var sql = "select m1(name) as newname,age,favors  from  source" //用户输入的sql
    if(args.length==9){
      inKafkaServers = args(0)
      outKafkaServers = args(1)
      inTopic = args(2)
      outTopic = args(3)
      groupId = args(4)
      inSchemaInfo = args(5)
      outSchemaInfo = args(6)
      funcInfo = args(7)
      sql = args(8)
    }

    //获取StreamTableEnvironment
    val env = StreamExecutionEnvironment.getExecutionEnvironment
    val ssSettings = EnvironmentSettings.newInstance().useBlinkPlanner().inStreamingMode().build()
    val ssTableEnv = StreamTableEnvironment.create(env, ssSettings)

    //组装source表建表语句
    val inTableSql_start = "create table source("
    //构造表的字段信息
    val inTableSql_middle = generateInField(inSchemaInfo)
    val inTableSql_end = ""+
                      ") with("+
                      "'connector' = 'kafka',"+
                      "'topic' = '"+inTopic+"',"+
                      "'properties.bootstrap.servers' = '"+inKafkaServers+"',"+
                      "'properties.group.id' = '"+groupId+"',"+
                      "'format' = 'json',"+
                      "'scan.startup.mode' = 'earliest-offset',"+
                      "'json.fail-on-missing-field' = 'false',"+
                      "'json.ignore-parse-errors' = 'true'"+
                      ")"
    val inTableSql = inTableSql_start + inTableSql_middle + inTableSql_end
    print("sql="+inTableSql)
    ssTableEnv.executeSql(inTableSql)

    //组装sink表建表语句
    val outTableSql_start = "create table sink("
    //构造表的字段信息
    val outTableSql_middle = generateInField(outSchemaInfo)
    val outTableSql_end = ""+
      ") with("+
      "'connector' = 'kafka',"+
      "'topic' = '"+outTopic+"',"+
      "'properties.bootstrap.servers' = '"+outKafkaServers+"',"+
      "'format' = 'json',"+
      "'sink.partitioner' = 'round-robin'"+
      ")"
    val outTableSql = outTableSql_start + outTableSql_middle + outTableSql_end

    ssTableEnv.executeSql(outTableSql)

    //注册自定义函数
    //注册公共自定义函数
    ssTableEnv.createTemporarySystemFunction("myUDF",new FlinkMyUDFTest())
    //注册个性化自定义函数
    registerUDF(funcInfo,ssTableEnv)

    //执行sql查询
    val res = ssTableEnv.sqlQuery(sql)
    //保存结果
    res.executeInsert("sink")

  }

  /**
   * 组装表的字段信息
   * @param schemaInfo
   * @return
   */
  def generateInField(schemaInfo: String): String ={
    //保证解析出来的字段顺序和原始字符串中的顺序一致
    val inSchemaJson = JSON.parseObject(schemaInfo,Feature.OrderedField)
    //val inSchemaJson = JSON.parseObject(schemaInfo)
    val inSchemaIt = inSchemaJson.entrySet().iterator()
    var inFields = ""
    var num = 1//记录字段编号
    while(inSchemaIt.hasNext){
      val entry = inSchemaIt.next()
      val key = entry.getKey
      val value = entry.getValue
      if(num>1){
        inFields = inFields + ","
      }
      inFields = inFields + key+" "+value+""
      num += 1
    }
    inFields
  }

  /**
   * 根据指定的udf名称，在任务中进行注册
   * 多个udf，中间用逗号隔开
   * @param funcInfo
   */
  def registerUDF(funcInfo: String, ssTableEnv: StreamTableEnvironment): Unit ={
    val jsonArr = JSON.parseArray(funcInfo)
    for(i <- 0 until jsonArr.size()){
      val jsonObj = jsonArr.getJSONObject(i)
      val name = jsonObj.getString("name")
      val mainClass = jsonObj.getString("mainClass")
      ssTableEnv.createTemporarySystemFunction(name,Class.forName(mainClass).newInstance().asInstanceOf[ScalarFunction])
    }
  }

}
